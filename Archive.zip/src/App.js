import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import html2canvas from "html2canvas";
import jsPDF from 'jspdf';
import {useState} from "react";
import axios from "axios";
import * as XLSX from "xlsx";

function App() {

    const [name, setName] = useState('');

    const printDocument = (i) => {

        const input = document.getElementById('print' + i);
        html2canvas(input)
            .then((canvas) => {
                const imgData = canvas.toDataURL('image/png');
                const pdf = new jsPDF({
                    orientation: "landscape",
                    unit: "mm",
                    format: [297, 210],
                });
                pdf.addImage(imgData, 'PNG', 0, 0);
                pdf.save("Certificate#" + i + ".pdf");
            });
    }

    const [nameAll, setNameAll] = useState('');

    const printAllDocument = () => {

        const _users = nameAll.split(',');

        let pDiv = document.getElementById('generate');

        _users.map((user, i) => {

            let _userName = user.split(' ');
            let _firstName = _userName[0];
            let _midlName = _userName[1];
            let _lastName = _userName[2];
            let userName = _firstName + ' ' + _midlName[0] + '. ';
            if (_lastName) {
                userName += _lastName[0] + '.';
            }
            let parr = document.createElement('div');
            parr.setAttribute('class', 'main-page');

            let _i = i + 1;
            parr.innerHTML =
                '<div id="print-' + _i + '" class="sub-page gStyle"> <h3 align="center" class="gTextStyle">' + userName + '</h3></div>';

            pDiv.appendChild(parr);
        })

        document.getElementById('downloadAll').classList.remove('d-none')
    }

    // V1

    const loadFromFile = () => {
        axios.get('https://yarikthe.github.io/certificate/files/users.json'
            , {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }
        )
            .then(function (response) {
                console.log(response)
                return response.json();
            })
            .then(function (myJson) {
                console.log(myJson);
                setData(myJson)
            });
    }

    const downloadAll = () => {

        const _users = nameAll.split(',');

        _users.map((user, i) => {
            let _i = i + 1;
            printDocument('-' + _i)
        })
    }

    const [data, setData] = useState();

    // V2

    const handleFileUpload = (e) => {
        const reader = new FileReader();
        reader.readAsBinaryString(e.target.files[0]);
        reader.onload = (e) => {
            const data = e.target.result;
            const workbook = XLSX.read(data, {type: "binary"});
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            const parsedData = XLSX.utils.sheet_to_json(sheet);
            setData(parsedData);
        };

        // document.getElementById('generateFromExcel').classList.remove('d-none');
    }

    const printAllDocument2 = () => {

        const _users = nameAll.split(',');

        let pDiv = document.getElementById('generate');

        {
            data.slice(0, data.length).map((row, rowIndex) => {

                    let _userName = Object.values(row).map((value, index) => index === 1 && value);
                    let userName = _userName.toString().split(',')[1];

                    let parr = document.createElement('div');
                    parr.setAttribute('class', 'main-page');

                    let _i = rowIndex + 1;
                    parr.innerHTML =
                        '<div id="print-' + _i + '" class="sub-page gStyle"> <h3 align="center" class="gTextStyle">' + userName + '</h3></div>';

                    pDiv.appendChild(parr);
                }
            )
        }

        document.getElementById('downloadAll').classList.remove('d-none')
    }

    const downloadAll2 = () => {

        data.slice(0, data.length).map((user, i) => {
            let _i = i + 1;
            printDocument('-' + _i)
        })
    }

    return (
        <div className="App container-fluid row">
            <div className={'col-md-3 border p-5'}>
                <label htmlFor="user-name">
                    <small className="text-secondary">
                        Учасник
                    </small>
                </label>
                <input type="text" className={'form-control'} onChange={(e) => {
                    setName(e.target.value)
                }}
                       placeholder={'Прізвище І.І.'}
                />
                <br/>
                <button className="btn btn-primary p-3" disabled={name === '' ? true : false}
                        onClick={() => printDocument('-' + 0)}>
                    PDF Download
                </button>
                <br/><br/>
                {/*<label htmlFor="user-name">*/}
                {/*    <small className="text-secondary">*/}
                {/*        Вставте список учасників розділивши їх <b>комою</b>!*/}
                {/*    </small>*/}
                {/*</label>*/}
                {/*<div className="multiple">*/}
                {/*    <textarea name="" id="" cols="30" rows="10" className="form-control" onChange={(e)=>{*/}
                {/*        setNameAll(e.target.value)*/}
                {/*    }}></textarea>*/}
                {/*</div>*/}
                {/*<br/>*/}
                {/*<div className="d-flex">*/}
                {/*    <button className="btn btn-primary p-3" disabled={nameAll === '' ? true : false} onClick={printAllDocument}>*/}
                {/*        Згенерувати*/}
                {/*    </button>*/}
                {/*    <div className="p-1"></div>*/}
                {/*    <button id={'downloadAll'} className="btn btn-outline-primary p-3 d-none" onClick={downloadAll}>*/}
                {/*        Завантажити*/}
                {/*    </button>*/}
                {/*</div>*/}

                {/*<br/>*/}
                {/*<br/>*/}
                <input
                    type="file"
                    accept=".xlsx, .xls"
                    className="btn btn-primary p-3 form-control"
                    onChange={handleFileUpload}
                />
                <div className="border p-2 rounded" style={{
                    height: '300px',
                    overflowY: 'scroll'
                }}>
                    {data && data.length > 0 && (
                        <table className="table">
                            <thead>
                            <tr>
                                {Object.keys(data[0]).map((key) => (
                                    <th key={key}>{key}</th>
                                ))}
                            </tr>
                            </thead>
                            <tbody>
                            {data.map((row, index) => (
                                <tr key={index}>
                                    {Object.values(row).map((value, index) => (
                                        <td key={index}>{value}</td>
                                    ))}
                                </tr>
                            ))}
                            </tbody>
                        </table>
                    )}
                </div>

                <br/>
                <div className="d-flex">
                    <button id={'generateFromExcel'} className="btn btn-primary p-3"
                            disabled={data === undefined ? true : false} onClick={printAllDocument2}>
                        Згенерувати {data && data.length + ' Сертифікатів'}
                    </button>
                    <div className="p-1"/>
                    <button id={'downloadAll'} className="btn btn-outline-primary p-3 d-none" onClick={downloadAll2}>
                        Завантажити
                    </button>
                </div>
                {/*<button className="btn btn-primary p-3" disabled={data === null ? true : false} onClick={loadFromFile}>*/}
                {/*    Завантажити з файлу*/}
                {/*</button>*/}

                {/*<br/>*/}
                {/*<br/>*/}
                {/*{*/}
                {/*    data && data.length > 0 && data.map((user, i) => <div key={i}>*/}
                {/*        /!*<small className="text-secondary">*!/*/}
                {/*        /!*    #{i+1}*!/*/}
                {/*        /!*</small>*!/*/}
                {/*        {user.name},*/}
                {/*    </div>)*/}
                {/*}*/}
            </div>
            <div className={'col-md-9 border'} style={{}}>

                <div id="generate"></div>

                <div className="main-page">
                    <div id={'print-0'} className="sub-page" style={{
                        backgroundImage: "url(" + "https://yarikthe.github.io/certificate/files/bg.png" + ")",
                        backgroundPosition: 'center',
                        backgroundSize: 'cover',
                        backgroundRepeat: 'no-repeat',
                        // padding: '20px',
                        // height: '100%',
                        // width: '1000px'
                    }}>
                        <h3 align='center' style={{
                            color: '#3A4E63',
                            marginTop: '190px',
                            fontSize: '45px',
                            textDecoration: 'underline'
                        }}>{name}</h3>
                    </div>
                </div>

                {/*<div id={'divToPrint'} className={'d-flex justify-content-center'} size="A4" layout="portrait">*/}
                {/*     <span className={'display-5 position-absolute'} style={{*/}
                {/*         marginTop: '270px',*/}
                {/*         color: '#3A4E63'*/}
                {/*     }}>*/}
                {/*        <b>*/}
                {/*            {name}*/}
                {/*        </b>*/}
                {/*    </span>*/}
                {/*    <img src="/files/bg.png" alt="certificate" className={'img-fluid'} />*/}
                {/*</div>*/}
                {/*<div id={'divToPrint'} className="d-flex justify-content-center border m-auto bg-secondary" style={{*/}
                {/*    backgroundImage: "url(" + "/files/bg.png" + ")",*/}
                {/*    backgroundPosition: 'center',*/}
                {/*    backgroundSize: 'contain',*/}
                {/*    backgroundRepeat: 'no-repeat',*/}
                {/*    // padding: '20px',*/}
                {/*    // height: '100%',*/}
                {/*    // width: '1000px'*/}
                {/*}}>*/}
                {/*<span className={'display-5'} style={{*/}
                {/*    marginTop: '250px',*/}
                {/*    color: '#3A4E63'*/}
                {/*}}>*/}
                {/*    <b>*/}
                {/*        {name}*/}
                {/*    </b>*/}
                {/*</span>*/}
                {/*</div>*/}
            </div>
        </div>
    );
}

export default App;
